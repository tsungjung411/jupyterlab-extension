"use strict";
(self["webpackChunkmy_menu"] = self["webpackChunkmy_menu"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Initialization data for the my_menu extension.
 */
const plugin = {
    id: 'my_menu:plugin',
    autoStart: true,
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    activate: (app, settingRegistry) => {
        console.log('JupyterLab extension my_menu is activated!');
        var enableSayHello = true;
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(settings => {
                console.log('my_menu settings loaded:', settings.composite);
                enableSayHello = settings.get('enableSayHello').composite;
            })
                .catch(reason => {
                console.error('Failed to load settings for my_menu.', reason);
            });
        }
        const COMMAND_ID1 = 'my_menu:say-hello';
        app.commands.addCommand(COMMAND_ID1, {
            label: '說 hello',
            isEnabled: () => { return enableSayHello; },
            isVisible: () => { return true; },
            execute: () => { alert('Hello!'); },
        });
        const COMMAND_ID2 = 'my_menu:enable-say-hello';
        app.commands.addCommand(COMMAND_ID2, {
            label: '啟用 [說 hello]',
            isToggled: () => {
                console.log("[my_menu] enableSayHello:", enableSayHello);
                return enableSayHello;
            },
            execute: () => {
                if (settingRegistry) {
                    Promise.all([app.restored, settingRegistry.load(plugin.id)])
                        .then(([_, settings]) => {
                        enableSayHello = !enableSayHello;
                        settings.set('enableSayHello', enableSayHello);
                        console.log("[my_menu] update 'enableSayHello' to", enableSayHello);
                    });
                }
            },
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.fa3b67f8331ed04a7168.js.map